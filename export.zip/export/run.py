"""
This file is used to run the application with VSCode breakpoint dugger functionality - 
Simply use the debug button on this file.

The app can ALSO be run using .venv/Scripts/flask run ... but VSCode breakpoints won't work!

A production webserver is useful because it allows GIL'd Python to run on separate threads 
by pre-forking instances. 

On Windows we can use ".venv\Scripts\waitress-serve --host 0.0.0.0 run:app" to play our app
on the local network using waitress
"""

from app import create_app

app = create_app()
if __name__ == '__main__':
    app.run(debug=True, use_debugger=False, use_reloader=False)