import numpy as np

def random_number_list():
    return np.random.randint(1e6, size=100)