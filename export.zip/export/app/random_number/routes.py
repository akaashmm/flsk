from flask import Blueprint, render_template
from pathlib import Path  # for automatic static_url_path generation
from . import random_number_list  # import custom python from __init__.py

random_number_blueprint = Blueprint('Random Numbers', __name__,  # name this blueprint for the navbar
                                    template_folder='templates', 
                                    static_folder='static', 
                                    static_url_path='/' + Path(__file__).parts[-2] + '/static')

@random_number_blueprint.route('/random_numbers')
def show_random_number():
    randoms_list = random_number_list()
    return render_template('r.html', random_numbers=randoms_list)