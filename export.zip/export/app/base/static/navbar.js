/* 
This script is responsible for quickly updating the page's 
clicked navbar color BEFORE the subsequent template is 
rendered. The new render uses request.blueprint in Jinja 
to assign the active_page class once the new page renders. 
*/
const nav_links = document.querySelectorAll('#navbar > a');
    
nav_links.forEach((clicked_link) => {
    clicked_link.addEventListener('click', (e) => {
        nav_links.forEach((link) => {
            link.classList.remove('active_page');
        });
        clicked_link.classList.add('active_page');
    });
});