from flask import Blueprint, render_template, send_from_directory, current_app
from pathlib import Path  # for automatic static_url_path generation
from . import uptime  # import custom python from __init__.py
import os

base_blueprint = Blueprint('Home', __name__,  # name this blueprint for the navbar
                           template_folder='templates', 
                           static_folder='static', 
                           static_url_path='/' + Path(__file__).parts[-2] + '/static')

@base_blueprint.route('/')
def home():
    current_uptime = uptime()
    return render_template('base.html', 
                           uptime=current_uptime)

@base_blueprint.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(current_app.root_path, 'base/static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')
