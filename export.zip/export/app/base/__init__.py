from datetime import datetime

creation_time = datetime.now()

def uptime():
    """returns a tuple of the current time and a string of the interval"""
    now = datetime.now()
    seconds_elapsed = (now - creation_time).seconds
    if seconds_elapsed < 100:
        uptime_str = f"{seconds_elapsed:.0f} seconds"
    elif seconds_elapsed < 3600:
        uptime_str = f"{seconds_elapsed / 60:.1f} minutes"
    elif seconds_elapsed < 3600 * 48:
        uptime_str = f"{seconds_elapsed / 3600:.1f} hours"
    else:
        uptime_str = f"{seconds_elapsed / 3600 / 24:.1f} days"
    return (creation_time, now, uptime_str)