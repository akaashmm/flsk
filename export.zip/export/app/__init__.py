from flask import Flask
import os
import importlib

APP_TITLE = 'Flask Starter App'
NAV_EXCLUSION_ROUTE_SUBSTRINGS = ['static', 'favicon.ico', 'reload']

def create_app():

    app = Flask(__name__, static_folder=None)

    # register all component blueprints - check each directory within the 'app' directory, 
    # if there is a routes.py file then import the routes.py file and register_blueprint()
    # any variables in that routes file ending with _blueprint
    components = [f.name for f in os.scandir('app') if f.is_dir() and f.name[0] != '_']
    for folder in components:
        if 'routes.py' in os.listdir('app/' + folder):
            routes = importlib.import_module('app.' + folder + '.routes')
            for var in dir(routes):
                if var.endswith('_blueprint'):
                    app.register_blueprint(getattr(routes, var))
            del routes

    # load context for page title and navigation
    # done using context because all blueprints extend base 
    @app.context_processor
    def base_template_variables():
        return dict(app_title=APP_TITLE, 
                    nav_routes=[(rule.rule, ' '.join(rule.endpoint.split('.')[:-1])) 
                                for rule in app.url_map.iter_rules() 
                                if all(exclusion not in rule.rule for exclusion 
                                in NAV_EXCLUSION_ROUTE_SUBSTRINGS)])

    # prevent jinja white space 
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True

    return app