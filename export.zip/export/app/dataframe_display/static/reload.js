function showNewData() {
    fetch("/dataframe_display/reload")
    .then(response => response.json())
    .then(data => {
        document.getElementById("df").innerHTML = data;
    })
}

var btn = document.getElementById("reload");
btn.addEventListener("click", showNewData);