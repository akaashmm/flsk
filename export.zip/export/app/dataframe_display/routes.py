from flask import Blueprint, render_template
from pathlib import Path  # for automatic static_url_path generation
from . import formatted_dataframe  # import custom python from __init__.py
import json

df_blueprint = Blueprint('Dataframe Display', __name__,  # name this blueprint for the navbar
                                    template_folder='templates', 
                                    static_folder='static', 
                                    static_url_path='/' + Path(__file__).parts[-2] + '/static')

@df_blueprint.route('/dataframe_display')  # main render-template method
def show_random_dataframe():
    return render_template('dataframe_display.html', df = formatted_dataframe())

@df_blueprint.route('/dataframe_display/reload')
def reload():
    return json.dumps(formatted_dataframe())
