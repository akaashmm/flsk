import numpy as np
import pandas as pd

def formatted_dataframe():
    size = 48
    roll = np.random.randint(1, 7, size=size).reshape([size//2, 2]) 
    return pd.DataFrame(roll, columns=['A', 'B']).to_html()